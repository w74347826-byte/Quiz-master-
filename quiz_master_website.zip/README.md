# Quiz Master — Android-friendly quiz website

A responsive purple-and-white quiz game built with HTML, CSS, JavaScript, Python, and Flask.

## Features
- 4 categories: Science, History, Geography, Technology
- 15 multiple-choice questions in each category (60 total)
- Randomized question order
- Instant answer feedback and progress bar
- Optional browser voice read-aloud
- Results screen and leaderboard
- Python Flask API and JSON-file score storage
- Responsive layout and light/dark theme

## Run on Android (recommended beginner path)
You can edit these files on Android, but the Python Flask backend needs a Python environment.

1. Install a Python coding app that supports Flask, or use an online Python IDE that supports web apps (for example, Replit in your browser).
2. Upload/extract this project folder.
3. Install packages:
   `pip install -r requirements.txt`
4. Run:
   `python app.py`
5. Open the web preview or visit `http://127.0.0.1:5000` in the same device/browser if the environment supports local web servers.

Online IDEs may have their own Run/Preview button and URL; use that URL rather than `127.0.0.1` if the project is running in the cloud.

## Files
- `app.py`: Flask backend and API routes
- `templates/index.html`: website pages and markup
- `static/style.css`: responsive purple-and-white theme
- `static/app.js`: navigation, quiz logic, voice mode, results and leaderboard
- `requirements.txt`: Python dependencies
- `scores.json`: created automatically after the first saved score

## API routes
- `GET /api/questions` — returns all categories and questions
- `GET /api/scores` — returns leaderboard scores
- `POST /api/scores` — saves a score

## Notes
- The website's voice option uses the browser Speech Synthesis API; support and available voices vary by browser/device.
- Scores are stored in `scores.json` on the server. This is suitable for a learning/demo project, not a high-traffic production leaderboard.
- Keep `debug=False` for this starter app. For public production hosting, use a production WSGI server and add appropriate security and storage.
