from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import json
import os
from pathlib import Path

app = Flask(__name__)
CORS(app)

DATA_FILE = Path(__file__).with_name("scores.json")

QUESTIONS = [
    {
        "category": "Science", "icon": "🔬", "description": "Discover how the world works",
        "questions": [
            ["Which planet is known as the Red Planet?", ["Venus", "Mars", "Jupiter", "Mercury"], 1],
            ["What is the chemical symbol for gold?", ["Ag", "Au", "Gd", "Go"], 1],
            ["Which cell part is called the powerhouse of the cell?", ["Nucleus", "Ribosome", "Mitochondria", "Golgi body"], 2],
            ["Which gas do plants absorb during photosynthesis?", ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"], 2],
            ["How many bones are in a typical adult human body?", ["206", "212", "198", "300"], 0],
            ["What is the approximate speed of light in a vacuum?", ["3,000 km/s", "30,000 km/s", "300,000 km/s", "3,000,000 km/s"], 2],
            ["Which is the hardest naturally occurring substance?", ["Quartz", "Diamond", "Steel", "Granite"], 1],
            ["At sea level, water boils at what temperature?", ["90°C", "100°C", "110°C", "120°C"], 1],
            ["What is the largest organ of the human body?", ["Liver", "Skin", "Lungs", "Heart"], 1],
            ["Which force pulls objects toward Earth?", ["Magnetism", "Friction", "Gravity", "Inertia"], 2],
            ["What is the closest star to Earth?", ["Sirius", "The Sun", "Proxima Centauri", "Polaris"], 1],
            ["Which vitamin can the body make with help from sunlight?", ["Vitamin A", "Vitamin C", "Vitamin D", "Vitamin K"], 2],
            ["What is the atomic number of hydrogen?", ["1", "2", "8", "6"], 0],
            ["Which gas makes up most of Earth's atmosphere?", ["Oxygen", "Nitrogen", "Argon", "Carbon dioxide"], 1],
            ["Who developed the theory of relativity?", ["Isaac Newton", "Albert Einstein", "Niels Bohr", "Galileo Galilei"], 1],
        ]
    },
    {
        "category": "History", "icon": "🏛️", "description": "Explore people and events from the past",
        "questions": [
            ["Who was the first President of the United States?", ["Abraham Lincoln", "George Washington", "Thomas Jefferson", "John Adams"], 1],
            ["Why were many ancient Egyptian pyramids built?", ["Markets", "Tombs for pharaohs", "Fortresses", "Schools"], 1],
            ["In which year did World War II end?", ["1939", "1945", "1950", "1918"], 1],
            ["Who painted the Mona Lisa?", ["Michelangelo", "Raphael", "Leonardo da Vinci", "Donatello"], 2],
            ["In which year did the Berlin Wall fall?", ["1979", "1985", "1989", "1991"], 2],
            ["Who was the first person to walk on the Moon?", ["Buzz Aldrin", "Yuri Gagarin", "Neil Armstrong", "Alan Shepard"], 2],
            ["Which language did ancient Romans commonly speak?", ["Greek", "Latin", "Italian", "Etruscan"], 1],
            ["In which year did the Titanic sink?", ["1905", "1912", "1920", "1898"], 1],
            ["Who was the first emperor to unify China?", ["Kublai Khan", "Qin Shi Huang", "Sun Yat-sen", "Liu Bang"], 1],
            ["In which year did Christopher Columbus reach the Americas?", ["1492", "1502", "1453", "1520"], 0],
            ["In which year did India gain independence?", ["1930", "1942", "1947", "1950"], 2],
            ["Where did the Industrial Revolution begin?", ["France", "Britain", "Germany", "United States"], 1],
            ["Who led India's non-violent independence movement?", ["Jawaharlal Nehru", "Mahatma Gandhi", "Subhas Chandra Bose", "Vallabhbhai Patel"], 1],
            ["Where did the ancient Olympic Games originate?", ["Rome", "Greece", "Egypt", "Persia"], 1],
            ["In which year did the French Revolution begin?", ["1689", "1789", "1799", "1815"], 1],
        ]
    },
    {
        "category": "Geography", "icon": "🌍", "description": "Travel the world through questions",
        "questions": [
            ["What is the capital of Australia?", ["Sydney", "Melbourne", "Canberra", "Perth"], 2],
            ["Which is the largest ocean on Earth?", ["Atlantic", "Indian", "Pacific", "Arctic"], 2],
            ["Which river is traditionally considered the world's longest?", ["Amazon", "Nile", "Yangtze", "Mississippi"], 1],
            ["Which is the largest country by land area?", ["Canada", "China", "Russia", "United States"], 2],
            ["Mount Everest is part of which mountain range?", ["Andes", "Alps", "Himalayas", "Rockies"], 2],
            ["What is the capital of Japan?", ["Kyoto", "Osaka", "Tokyo", "Nagoya"], 2],
            ["What is the largest hot desert in the world?", ["Gobi", "Sahara", "Kalahari", "Thar"], 1],
            ["How many continents are commonly recognized?", ["5", "6", "7", "8"], 2],
            ["What is the capital of Canada?", ["Toronto", "Ottawa", "Vancouver", "Montreal"], 1],
            ["Which country currently has the largest population?", ["China", "India", "United States", "Indonesia"], 1],
            ["What is the capital of Pakistan?", ["Karachi", "Lahore", "Islamabad", "Peshawar"], 2],
            ["Which is the world's smallest independent country by area?", ["Monaco", "Vatican City", "Malta", "San Marino"], 1],
            ["Most of the Amazon rainforest is in which country?", ["Peru", "Colombia", "Brazil", "Venezuela"], 2],
            ["Which sea lies between Europe and Africa?", ["Red Sea", "Mediterranean Sea", "Baltic Sea", "Caspian Sea"], 1],
            ["What is the capital of Egypt?", ["Alexandria", "Cairo", "Giza", "Luxor"], 1],
        ]
    },
    {
        "category": "Technology", "icon": "💻", "description": "Test your digital and computing knowledge",
        "questions": [
            ["What does HTML stand for?", ["HyperText Markup Language", "High Text Machine Language", "Hyper Tool Multi Language", "Home Text Markup Link"], 0],
            ["Who co-founded Microsoft with Paul Allen?", ["Steve Jobs", "Bill Gates", "Elon Musk", "Larry Page"], 1],
            ["What does CPU stand for?", ["Central Process Utility", "Computer Personal Unit", "Central Processing Unit", "Core Power Unit"], 2],
            ["Which language is mainly used to style web pages?", ["Python", "CSS", "SQL", "Java"], 1],
            ["Which company develops Android?", ["Apple", "Google", "Nokia", "Samsung"], 1],
            ["How many bits are in one byte?", ["4", "8", "16", "32"], 1],
            ["Who invented the World Wide Web?", ["Tim Berners-Lee", "Linus Torvalds", "Alan Turing", "Mark Zuckerberg"], 0],
            ["What is Python?", ["A browser", "A programming language", "A database", "An operating system"], 1],
            ["Which of these is a database system?", ["Linux", "MySQL", "Chrome", "Python"], 1],
            ["What does RAM stand for?", ["Read Access Memory", "Run All Modules", "Random Access Memory", "Rapid Active Mode"], 2],
            ["Which company makes the iPhone?", ["Samsung", "Apple", "Sony", "LG"], 1],
            ["What is Wi-Fi mainly used for?", ["Printing", "Wireless networking", "Charging", "Cooling"], 1],
            ["Where does JavaScript commonly run for web apps?", ["Printer", "Web browser", "Router firmware", "BIOS"], 1],
            ["What is the usual file extension for Python files?", [".pt", ".py", ".pn", ".pyt"], 1],
            ["What does AI stand for?", ["Automated Input", "Artificial Intelligence", "Advanced Internet", "Applied Interface"], 1],
        ]
    }
]

def load_scores():
    try:
        if DATA_FILE.exists():
            data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        pass
    return []

def save_scores(scores):
    DATA_FILE.write_text(json.dumps(scores, ensure_ascii=False, indent=2), encoding="utf-8")

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/questions")
def questions():
    return jsonify(QUESTIONS)

@app.get("/api/scores")
def get_scores():
    scores = sorted(load_scores(), key=lambda r: (r.get("score", 0) / max(r.get("total", 1), 1)), reverse=True)
    return jsonify(scores[:50])

@app.post("/api/scores")
def post_score():
    payload = request.get_json(silent=True) or {}
    name = str(payload.get("name", "Player")).strip()[:20] or "Player"
    category = str(payload.get("category", "General")).strip()[:30] or "General"
    try:
        score = int(payload.get("score", 0))
        total = int(payload.get("total", 15))
    except (TypeError, ValueError):
        return jsonify({"error": "Score and total must be numbers."}), 400
    if total < 1 or score < 0 or score > total:
        return jsonify({"error": "Invalid score."}), 400
    scores = load_scores()
    scores.append({"name": name, "category": category, "score": score, "total": total})
    save_scores(scores)
    return jsonify({"message": "Score saved."}), 201

if __name__ == "__main__":
    # For local development only. Use a production server when deploying publicly.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
